package ru.luminar.utils.themes;

import java.util.Iterator;
import java.util.List;

public class ThemeManager {
   final List<Theme> styleList;
   Theme currentStyle;

   public Theme getStyleByName(String name) {
      Iterator iterator = this.styleList.iterator();

      while(iterator.hasNext()) {
         Theme style = (Theme)iterator.next();
         if (style.getStyleName().equalsIgnoreCase(name)) {
            return style;
         }
      }

      return null;
   }

   public ThemeManager(List<Theme> styleList, Theme currentStyle) {
      this.styleList = styleList;
      this.currentStyle = currentStyle;
   }

   public List<Theme> getStyleList() {
      return this.styleList;
   }

   public Theme getCurrentStyle() {
      return this.currentStyle;
   }

   public void setCurrentStyle(Theme style) {
      this.currentStyle = style;
   }
}
