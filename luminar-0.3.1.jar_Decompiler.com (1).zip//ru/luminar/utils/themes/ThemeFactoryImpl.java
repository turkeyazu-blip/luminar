package ru.luminar.utils.themes;

import java.awt.Color;

public class ThemeFactoryImpl implements ThemeFactory {
   public Theme createStyle(String name, Color firstColor, Color secondColor) {
      return new Theme(name, firstColor, secondColor);
   }
}
