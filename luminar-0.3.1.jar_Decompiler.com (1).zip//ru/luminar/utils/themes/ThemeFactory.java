package ru.luminar.utils.themes;

import java.awt.Color;

public interface ThemeFactory {
   Theme createStyle(String var1, Color var2, Color var3);
}
