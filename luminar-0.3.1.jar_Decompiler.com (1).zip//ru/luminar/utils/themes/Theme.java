package ru.luminar.utils.themes;

import java.awt.Color;
import ru.luminar.utils.draw.ColorUtils;

public class Theme {
   String styleName;
   Color firstColor;
   Color secondColor;

   public Theme(String name, Color cl1, Color cl2) {
      this.styleName = name;
      this.firstColor = cl1;
      this.secondColor = cl2;
   }

   public String getStyleName() {
      return this.styleName;
   }

   public Color getFirstColor() {
      return this.firstColor;
   }

   public Color getSecondColor() {
      return this.secondColor;
   }

   public int getColor(int index) {
      return ColorUtils.gradient(this.firstColor.getRGB(), this.secondColor.getRGB(), index, 15);
   }

   public int getColor(int index, int speed) {
      return ColorUtils.gradient(this.firstColor.getRGB(), this.secondColor.getRGB(), index, speed);
   }

   public void setFirstColor(Color firstColor) {
      this.firstColor = firstColor;
   }

   public void setSecondColor(Color secondColor) {
      this.secondColor = secondColor;
   }
}
