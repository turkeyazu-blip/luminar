package ru.luminar.utils.draw.font;

public class Fonts {
   public static Font montserrat;
   public static Font INTER_MEDIUM;
   public static Font consolas;
   public static Font sf_semibold;
   public static Font sf_regular;
   public static Font sf_medium;
   public static Font nuralphaicons;
   public static Font sfui;
   public static Font sfbold;
   public static Font sfMedium;
   public static Font poppinsSb;
   public static Font poppinsBold;
   public static Font promobold;
   public static Font promomed;
}
