package ru.luminar.utils.client;

public interface MouseReleaseHandler {
   void onMouseReleased(int var1);
}
