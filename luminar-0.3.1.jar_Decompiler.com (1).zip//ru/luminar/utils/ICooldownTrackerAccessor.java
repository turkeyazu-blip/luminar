package ru.luminar.utils;

import net.minecraft.item.Item;

public interface ICooldownTrackerAccessor {
   float getCooldownSeconds(Item var1, float var2);
}
