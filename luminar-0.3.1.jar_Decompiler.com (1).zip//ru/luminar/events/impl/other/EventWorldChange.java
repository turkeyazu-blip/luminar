package ru.luminar.events.impl.other;

import ru.luminar.events.Event;

public class EventWorldChange extends Event {
}
