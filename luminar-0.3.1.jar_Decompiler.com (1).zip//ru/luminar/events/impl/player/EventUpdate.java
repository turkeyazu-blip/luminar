package ru.luminar.events.impl.player;

import ru.luminar.events.Event;

public class EventUpdate extends Event {
}
