package ru.luminar.feature.command.api.interfaces;

public interface Logger {
   void log(String var1);
}
