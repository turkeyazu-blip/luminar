package ru.luminar.feature.command.api.interfaces;

import java.util.List;

public interface MultiNamedCommand {
   List<String> aliases();
}
