package ru.luminar.feature.command.api.interfaces;

public interface Prefix {
   String get();
}
