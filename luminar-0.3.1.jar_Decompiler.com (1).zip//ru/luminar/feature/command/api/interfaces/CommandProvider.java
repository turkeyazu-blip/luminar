package ru.luminar.feature.command.api.interfaces;

public interface CommandProvider {
   Command command(String var1);
}
