package ru.luminar.feature.command.api.interfaces;

public interface ParametersFactory {
   Parameters createParameters(String var1, String var2);
}
