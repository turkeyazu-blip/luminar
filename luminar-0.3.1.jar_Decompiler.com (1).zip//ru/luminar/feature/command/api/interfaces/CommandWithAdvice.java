package ru.luminar.feature.command.api.interfaces;

import java.util.List;

public interface CommandWithAdvice {
   List<String> adviceMessage();
}
