package ru.luminar.feature.command.api.impl;

import ru.luminar.feature.command.api.interfaces.Logger;

public class ConsoleLogger implements Logger {
   public void log(String message) {
   }
}
