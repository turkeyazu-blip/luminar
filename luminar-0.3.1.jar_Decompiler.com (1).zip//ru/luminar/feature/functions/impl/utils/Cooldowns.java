package ru.luminar.feature.functions.impl.utils;

import ru.luminar.feature.functions.Category;
import ru.luminar.feature.functions.Function;

public class Cooldowns extends Function {
   public Cooldowns() {
      super("Cooldowns", Category.Utils);
   }
}
