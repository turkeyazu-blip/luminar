package ru.luminar.feature.functions.impl.render.hud;

public class Keybinds {
}
