package ru.luminar.feature.functions;

public enum Category {
   Render,
   Utils;

   // $FF: synthetic method
   private static Category[] $values() {
      return new Category[]{Render, Utils};
   }
}
